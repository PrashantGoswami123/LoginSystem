<html>
<head>

<script src="jquery-3.4.1.min.js" >
</script>

<style>
body{
	background-image:url("img1.jpg")
}
.fo{
margin-right:auto;
margin-left:auto;
width:30%;
display:block;
}
form {
background-color:rgba(255,255,255,0.3);
margin-right:auto;
margin-left:auto;
width:30%;
display:block;
margin-top:200px;
border:20px gray ridge;
padding:20px;
box-shadow:4px 4px 4px white;
}

label{
font-size:16px;
font-weight:bold;
font-family:calibri;
}
.d4
{
margin:10px;
height:30px;
width:180px;
font-size:15px;

color:white;
font-weight:bold;
text-align:center;
background-color:red
}
.d3{
background-color:blue;
height:30px;
width:80px;
font-size:15px;
padding:5px;
color:white;

text-align:center;

}

.d1,.d2{
height:30px;
width:150px;
border-style:solid;
border-radius:15px;
text-align:center;
}
 
</style>
</head>
<body>
<form id="f1" method="post" action="l2.php" onsubmit="return validation()">
<div class="fo">
<div class="f">
<label>Username</label><br/>
<input onkeyup="return validation()" class="d1" type="text" placeholder="Enter your name" 
 autofocus autuocomplete="on" id="username"  name="username"/>
</div><br/><span id="err1"></span>
<div class="f">
<label>Email</label><br/>
<input onkeyup="return validation()"
 class="d1"type="mail" placeholder="Enter your mail address" 
 autofocus autuocomplete="on" id="email" name="email"/>
</div><br/><span id="err2"></span>

<div class="f">
<label>Password</label><br/>
<input onkeyup="return validation()" class="d2" type="password" placeholder="Enter your password" 
 autofocus autuocomplete="off" id="password" name="password"/>
</div>
<br/>
<span id="err3"></span>
<div class="f">
<label>Confirm Password</label><br/>
<input onkeyup="return validation()" class="d2" type="password" placeholder="Confirm password" 
autofocus autuocomplete="off" id="con" name="con"/>
</div><br/><span id="err4"></span>
<div class="f">
         <input class="d4" type="submit" name="submit" id="submit" value="Create your account"/>
</div><br/>
<div class="f">
<input class="d3"type="reset" name="reset" value="Reset"/>
</div>
</div>
</form>

<script>

$(document).ready(function()
{
$('#submit').click(function(){

 $(".dd").hide();
    
   

})

}
)

</script>
<div name="err5" id="err5"></div>
<script>
function validation()
{
var name=document.getElementById("username").value;
var email=document.getElementById("email").value;
var password=document.getElementById("password").value;
var con=document.getElementById("con").value;	
err1=document.getElementById("err1");
err2=document.getElementById("err2");
err3=document.getElementById("err3");
err4=document.getElementById("err4");
	var a=[name,email,password,con]
	var b=[err1,err2,err3,err4];
    var c=["name","email","password","password again"];
     for(i=0;i<=3;i++)
	 {
		 if(a[i].length==0)
		 {
			 b[i].innerHTML="*Please enter your " +c[i];
		 b[i].style.color="red";
		 }
		 
		 }
	
	
	//name validation
var n=/^[A-Za-z]+$/;
var e=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
	
	if(name.length<6)
	{
		err1.innerHTML="*Name should have atleast 6 characters";
        err1.style.color="red";
    }
else{    
	if(n.test(name))
	{
		err1.innerHTML="*Valid";
        err1.style.color="red";
     	
	}	
	else{
		err1.innerHTML="*Only alphabets are allowed in name ";
        err1.style.color="red";
     	}
}

if(e.test(email))
{
		err2.innerHTML="*Valid";
      err2.style.color="red";
   }	
	else{
		err2.innerHTML="*Invalid Email";
      err2.style.color="red";
   	
	}

	
	if(password.length<6)
	{
		err3.innerHTML="*Password should have atleast 6 characters";
      err3.style.color="red";
   	}
	else{   if(password.length>=6){
			err3.innerHTML="*Valid";
	err3.style.color="red";   }
	
	
	if(password==con)
	{
			err4.innerHTML="*Valid";
      err4.style.color="red";
		}
		else{
			err4.innerHTML="*Password do not match";
      err4.style.color="red";
			
		}
	}
	
	var count=0;
	for(j=0;j<=3;j++)
	{
		if(b[j].innerHTML=="*Valid")
		{
			count++;
		}
	}

	if(count==4)
	{
		return true;
		}
	else { 
		return false;
	}
	
}
	
	
		
	
 









</script>

<?php

define('SITE_URL', 'http://localhost/');
if(isset($_POST['submit']))
{
$username=$_POST['username'];
$email=$_POST['email'];
$password=$_POST['password'];
$code=substr(md5(mt_rand()),0,15);
 $con=mysqli_connect('localhost','root','','users');
 $q2="select * from verified_users where email='$email'";
 $c=mysqli_query($con,$q2);
 $check=mysqli_fetch_assoc($c);
 if(!$check){
 $q="insert into user (username,email,password,code) values('$username','$email','$password','$code')";
 mysqli_query($con,$q);
 mysqli_close($con);
 if(isset($username)){
 echo "you have successfully registered your account";
      
        $message = '<html><head>
                <title>Email Verification</title>
                </head>
                <body>';
        $message .= '<h1>Hi!</h1>';
        $message .= '<p><a href="'.SITE_URL.'a1.php?id=' . $code. '">CLICK TO ACTIVATE YOUR ACCOUNT</a>';
        $message .= "</body></html>";
        
require 'PHPMailerAutoload.php';

$mail = new PHPMailer();

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup server
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Port=465;
$mail->Username = 'XYZ@gmail.com';                            // SMTP username (senders mail address)
$mail->Password = '*********';                           // SMTP password      (passwords)
$mail->SMTPSecure = 'ssl';                            // Enable encryption, 'ssl' also accepted

$mail->From = 'XYZ@gmail.com';//senders mail id
$mail->FromName = 'XYZ';//name
$mail->addAddress("$email");  // Name is optional


$mail->WordWrap = 50;  
$mail->isHTML(true);                                  // Set email format to HTML
$mail->Subject = "Here is the subject";
$mail->Body    = "$message";
$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->send()) {
   echo"<center><div class='dd' style='position:relative;bottom:580px;display:inline;text-align:center;padding:10px;background-color:orange;color:red;font-size:15px;font-weight:bold'>Verification link canot be send to your mail,please try again</div></center>";

   echo "Mailer Error: '' ". $mail->ErrorInfo;
   exit;
}

echo"<center><div class='dd' style='position:relative;bottom:580px;display:inline;text-align:center;padding:10px;background-color:orange;color:red;font-size:15px;font-weight:bold'>A verification link has been send to your mail. </div></center>";
}}
else{
	?><center><div class="dd" style='position:relative;bottom:580px;
	display:inline;text-align:center;padding:10px;background-color:orange;color:red;font-size:15px;font-weight:bold;display:hidden;'>
	This email has already been taken</div></center>
	<?php
	echo"";
}

}
 ?>

<script>

$(document).ready(function()
{


 $(".dd").show();
    $(".dd").delay(1000).fadeOut(500);


    
  }
)

</script>
</body>
</html>
