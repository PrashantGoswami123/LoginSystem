<html>
<head>
<script src="jquery-3.4.1.min.js" >
</script>

<style>
body{
background:url("img1.jpg");
}

form {
background-color:rgba(255,255,255,0.3);
margin-right:auto;
margin-left:auto;
display:block;
text-align:center;
margin-top:200px;
width:30%;
border:20px gray ridge;
padding:30px;
box-shadow:4px 4px 4px white;
}

label{
font-size:25px;
font-weight:bold;
font-family:calibri;
}
.d4
{
margin:10px;
height:30px;
width:80px;
font-size:15px;

color:white;
font-weight:bold;
text-align:center;
background-color:red
}
.d3{
background-color:blue;
height:30px;
width:80px;
font-size:15px;
padding:5px;
color:white;

text-align:center;

}

.d1,.d2{
height:30px;
width:150px;
border-style:solid;
border-radius:15px;
text-align:center;
}
 
</style>
</head>
<body>
<form id="f1" method="post" action="l1.php">
<div class="f">
<label>Email</label>
<input class="d1"type="text"name="email" placeholder="Enter your email" 
required autofocus autuocomplete="on" />
</div><br/>
<div class="f">
<label>Password</label>
<input class="d2" name="pass" type="password" placeholder="Enter your password" 
required autofocus autuocomplete="off" />
</div>
<br/><br/>
<div class="f">
<input class="d4" type="submit" name="submit" value="Login"/>
<a href="l2.php"><input class="d4" type="button" name="signup" value="Register"/>
</a></div>
<div class="f">
<input class="d3"type="reset" name="reset" value="Reset"/>
</div>
</form>
<?php
session_start();

if(isset($_GET['msg']))
{
$msg=$_GET['msg'];
	echo "<center><div class='dd' style='position:relative;bottom:400px;
	display:inline;text-align:center;padding:10px;background-color:orange;color:red;font-size:15px;font-weight:bold;display:hidden'>$msg</div></center>";
}
if(isset($_POST['submit']))
{

$email=$_POST['email'];
$pass=$_POST['pass'];
$con=mysqli_connect('localhost','root','','users');
$q= "select * from verified_users where email='$email' and password='$pass'";
$x=mysqli_query($con,$q);
$arr=mysqli_fetch_assoc($x);
if($arr)
{
	$_SESSION['email']=$email;
	$_SESSION['password']=$pass;
	header("Location:h1.php");
}
 else
 {
	

	echo "<center><div class='dd' style='position:relative;bottom:400px;
	display:inline;text-align:center;padding:10px;background-color:orange;color:red;font-size:15px;font-weight:bold;display:hidden'>
	Invalid email or password</div></center>";
	


 }



 
}

?>

<script>

$(document).ready(function()
{


 $(".dd").show();
    $(".dd").delay(1000).fadeOut(500);


    
  }
)

</script>
</body>
</html>