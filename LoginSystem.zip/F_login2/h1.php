<?php
session_start();
if(isset($_SESSION['email'])){
echo "You are successfully logged in...!!!!";
echo "<a href='l3.php'><button>Log out</button></a>";}
else
	header("Location:l1.php");
?>

