
<?php

$con=mysqli_connect("localhost","root","","users");
 $code=$_GET['id'];
 $q1="select * from user where code='$code'";
 $c=mysqli_query($con,$q1);
 $check=mysqli_fetch_assoc($c);
 if($check)
 {
	 $email=$check['email'];
	 $password=$check['password'];
	 $q2="insert into verified_users (email,password) values ('$email','$password')";
      mysqli_query($con,$q2);	 
      header("Location:l1.php?msg=You have registered  your account successfully");
 }
else
{    
     header("Location:l1.php?msg=Your registration become unsuccessfull ,Please try again");
 }
mysqli_close($con);
?>